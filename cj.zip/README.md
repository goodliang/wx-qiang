
clone 代码到本地

```＃npm install```  安装依赖

```#node app.js```  node 运行

演示地址 ：http://115.28.240.188:8080/
